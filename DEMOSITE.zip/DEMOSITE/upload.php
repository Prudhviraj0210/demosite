<?php

if (isset($_POST['sub'])) 
{   
	$db = mysqli_connect("localhost", "root", "", "dummy");
	$Fname = $_POST['first_name'];
	$Lname = $_POST['last_name'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$image = $_FILES['image']['name'];

	$target = "store/".basename($_FILES['image']['name']);


		$sql = "INSERT INTO dummy (FristName,LastName,Email,PhoneNO,File) VALUES ('$Fname','$Lname','$email','$phone','$image')";
		mysqli_query($db, $sql);

		if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) 
		{
	   echo "<script>alert('Yours Details successfully Stored');window.location='index.html'</script>";
		}
		else
		{
			echo  "<script>alert('Ple Fill The all Details');window.location='upload.html'</script>";
		}
	
}
?>