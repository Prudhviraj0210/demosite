<?php
if (isset($_POST['sub'])) 
{

mysql_connect("localhost","root","");
mysql_select_db("dummy");
$username=$_POST['email'];
$password=$_POST['pass'];
$result=mysql_query("select * from login where username='$username' AND password='$password' ") or die(mysql_error());
$row=mysql_fetch_array($result);
if($row['username']==$username AND $row['password']==$password)
{
	echo "<script>alert('LogIn  successfully');window.location='test1.html'</script>";
}
else
{
	echo "<script>alert('Login Details Error');window.location='log.html'</script>";
}
}
?>